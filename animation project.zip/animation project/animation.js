// *******************************************************
// CS 174a Graphics Example Code
// animation.js - The main file and program start point.  The class definition here describes how to display an Animation and how it will react to key and mouse input.  Right now it has 
// no meaningful scenes to draw - you will fill it in (at the bottom of the file) with all your shape drawing calls and any extra key / mouse controls.  

// Now go down to display() to see where the sample shapes you see drawn are coded, and where to fill in your own code.

"use strict"      // Selects strict javascript
var canvas, canvas_size, shaders, gl = null, g_addrs,          // Global variables
	thrust = vec3(), 	origin = vec3( 0, 10, -15 ), looking = false, prev_time = 0, animate = false, animation_time = 0, gouraud = false, color_normals = false;
//background
var doc = "day.png";

//robot
//position
var x_pos = 10.0;
var y_pos = 4.0;
var z_pos = -16.0;
var body_angle = 0;
var head_angle = 0;
var camera_x = 0;
var camera_y = 80;
var camera_z = 80;
var obj_x = 0;
var obj_y = 60;
var obj_z = 0;
var text_z = 50;

//bird
var wings_angle = 0;
var bird_pos_x = 10;
var bird_pos_y = 70;
var bird_pos_z = 40;



//scene
//charge_bar
var battery = 6;
var battery_light = .2;
var chair_pos = -8.5;

//back & front
var arm_angle1 = 0;
var arm_axis1 = 0;
var arm_angle2 = 0;
// side

var arm_angle3 =-10;
var arm_axis2;
var arm_angle4 =10;

//second part arm
var arm_angle5 =0;
var arm_axis3;
var arm_angle6 =0;

//hand
var arm_angle7 =0;
var arm_axis3;
var arm_angle8 =0;

//second part arm
var arm_angle9 = 0;
var arm_angle10 = 0;

var leg_angle1 = 0;
var leg_angle2 = 0;

var leg_angle3 = 0;
var leg_angle4 = 0;


// scene motion
var door_angle = 0;





// *******************************************************
// IMPORTANT -- Any new variables you define in the shader programs need to be in the list below, so their GPU addresses get retrieved.

var shader_variable_names = [ "camera_transform", "camera_model_transform", "projection_camera_model_transform", "camera_model_transform_normal",
                              "shapeColor", "lightColor", "lightPosition", "attenuation_factor", "ambient", "diffusivity", "shininess", "smoothness", 
                              "animation_time", "COLOR_NORMALS", "GOURAUD", "USE_TEXTURE" ];
   
function Color( r, g, b, a ) { return vec4( r, g, b, a ); }     // Colors are just special vec4s expressed as: ( red, green, blue, opacity )
function CURRENT_BASIS_IS_WORTH_SHOWING(self, model_transform) { self.m_axis.draw( self.basis_id++, self.graphicsState, model_transform, new Material( Color( .8,.3,.8,1 ), .1, 1, 1, 40, undefined ) ); }

// *******************************************************
// IMPORTANT -- In the line below, add the filenames of any new images you want to include for textures!

var texture_filenames_to_load = [ "stars.png", "text.png", "earth.gif","night.png","day.png" ,"day2.gif","copper.png","iron.png","brick.png","floor.png","wallpaper2.png"];

window.onload = function init() {	var anim = new Animation();	}   // Our whole program's entry point

// *******************************************************	
// When the web page's window loads it creates an "Animation" object.  It registers itself as a displayable object to our other class "GL_Context" -- 
// which OpenGL is told to call upon every time a draw / keyboard / mouse event happens.
function Animation()    // A class.  An example of a displayable object that our class GL_Context can manage.
{
	( function init( self )
	{
		self.context = new GL_Context( "gl-canvas", Color(0.6,0.86,1,0.8));    // Set your background color here
		self.context.register_display_object( self );
		
    shaders = { "Default":     new Shader( "vertex-shader-id", "fragment-shader-id" ), 
                "Demo_Shader": new Shader( "vertex-shader-id", "demo-shader-id"     )  };
    
		for( var i = 0; i < texture_filenames_to_load.length; i++ )
			initTexture( texture_filenames_to_load[i], true );
    self.mouse = { "from_center": vec2() };
		            
    self.m_strip       = new Old_Square();                // At the beginning of our program, instantiate all shapes we plan to use, 
		self.m_tip         = new Tip( 3, 10 );                // each with only one instance in the graphics card's memory.
    self.m_cylinder    = new Cylindrical_Tube( 10, 10 );  // For example we'll only create one "cube" blueprint in the GPU, but we'll re-use 
    self.m_torus       = new Torus( 25, 25 );             // it many times per call to display to get multiple cubes in the scene.
    self.m_sphere      = new Sphere( 10, 10 );
    self.poly          = new N_Polygon( 7 );
    self.m_cone        = new Cone( 10, 10 );
    self.m_capped      = new Capped_Cylinder( 4, 12 );
    self.m_prism       = new Prism( 8, 8 );
    self.m_cube        = new Cube();
    self.m_obj         = new Shape_From_File( "teapot.obj", scale( .1, .1, .1 ) );
    self.m_sub         = new Subdivision_Sphere( 4, true );
    self.m_axis        = new Axis();
    self.table         = new Shape_From_File( "Table.obj", scale( .2, .17, .2 ) );
    self.chair         = new Shape_From_File("chair.obj",   scale(33,45,33));
    self.desk          = new Shape_From_File( "desk.obj", scale( 6, 6, 6 ) );
    self.birdperch     = new Shape_From_File("BirdPerch.obj",   scale(.02,0.02,0.02));
    self.sofa     = new Shape_From_File("Sofa.obj",   scale(.2,0.2,0.2));
    self.lamp     = new Shape_From_File("lamp.obj",   scale(12,12,12));
    self.tv            = new Shape_From_File("tv_set.obj",   scale(0.8,0.8,0.8));
    self.pc            = new Shape_From_File("pc.obj",   scale(.02,0.02,0.02));
    self.cabinet            = new Shape_From_File("cabinet.obj",   scale(2,2,2));
    self.door          = new Shape_From_File("Door.obj",   scale(0.07,0.07,0.07));
    self.cloud         = new Shape_From_File("cloud.obj",   scale(3,3,3));
    self.stars         = new Shape_From_File("star.obj",   scale(2,2,2));
    self.pyramid   = new Pyramid();
    self.fps = 0;
    self.brick_color = new Material( Color( 0,0,0,1 ), 1,  1,  1, 40, "brick.png" );
		self.copper_color = new Material( Color( 0,0,0,1 ), 1,  1,  1, 40, "copper.png" );
    self.iron_color = new Material( Color( 0,0,0,1 ), 1,  1,  1, 40, "iron.png" );
    self.floor_color = new Material( Color( 0,0,0,1 ), 1,  1,  1, 40, "floor.png" );
    self.wall_color = new Material( Color( 0,0,0,1 ), 1,  1,  1, 40, "wallpaper2.png" );
    self.m_text = new Shape_From_File("text.obj",   mult(rotation(180,0,1,0),scale(2,2,2)));
    self.sound1 = new Audio("./type.wav");
    self.sound2 = new Audio("./music.mp3");
// 1st parameter is our starting camera matrix.  2nd parameter is the projection:  The matrix that determines how depth is treated.  It projects 3D points onto a plane.
		self.graphicsState = new GraphicsState( translation(0, 0,-25), perspective(45, canvas.width/canvas.height, .1, 1000), 0 );
		
		self.context.render();	




	} ) ( this );
	
// *** Mouse controls: ***
  var mouse_position = function( e ) { return vec2( e.clientX - canvas.width/2, e.clientY - canvas.height/2 ); };   // Measure mouse steering, for rotating the flyaround camera.     
  canvas.addEventListener("mouseup",   ( function(self) { return function(e)	{ e = e || window.event;		self.mouse.anchor = undefined;              } } ) (this), false );
	canvas.addEventListener("mousedown", ( function(self) { return function(e)	{	e = e || window.event;    self.mouse.anchor = mouse_position(e);      } } ) (this), false );
  canvas.addEventListener("mousemove", ( function(self) { return function(e)	{ e = e || window.event;    self.mouse.from_center = mouse_position(e); } } ) (this), false );                                         
  canvas.addEventListener("mouseout", ( function(self) { return function(e)	{ self.mouse.from_center = vec2(); }; } ) (this), false );        // Stop steering if the mouse leaves the canvas. 
}
  
// *******************************************************	
// init_keys():  Define any extra keyboard shortcuts here
Animation.prototype.init_keys = function()
{
	shortcut.add( "Space", function() { thrust[1] = -1; } );			shortcut.add( "Space", function() { thrust[1] =  0; }, {'type':'keyup'} );
	shortcut.add( "z",     function() { thrust[1] =  1; } );			shortcut.add( "z",     function() { thrust[1] =  0; }, {'type':'keyup'} );
	shortcut.add( "w",     function() { thrust[2] =  1; } );			shortcut.add( "w",     function() { thrust[2] =  0; }, {'type':'keyup'} );
	shortcut.add( "a",     function() { thrust[0] =  1; } );			shortcut.add( "a",     function() { thrust[0] =  0; }, {'type':'keyup'} );
	shortcut.add( "s",     function() { thrust[2] = -1; } );			shortcut.add( "s",     function() { thrust[2] =  0; }, {'type':'keyup'} );
	shortcut.add( "d",     function() { thrust[0] = -1; } );			shortcut.add( "d",     function() { thrust[0] =  0; }, {'type':'keyup'} );
	shortcut.add( "f",     function() { looking = !looking; } );
	shortcut.add( ",",   ( function(self) { return function() { self.graphicsState.camera_transform = mult( rotation( 3, 0, 0,  1 ), self.graphicsState.camera_transform       ); } } ) (this) ) ;
	shortcut.add( ".",   ( function(self) { return function() { self.graphicsState.camera_transform = mult( rotation( 3, 0, 0, -1 ), self.graphicsState.camera_transform       ); } } ) (this) ) ;
  shortcut.add( "o",   ( function(self) { return function() { origin = vec3( mult_vec( inverse( self.graphicsState.camera_transform ), vec4(0,0,0,1) )                       ); } } ) (this) ) ;
	shortcut.add( "r",   ( function(self) { return function() { self.graphicsState.camera_transform = mat4(); }; } ) (this) );
	shortcut.add( "ALT+g", function() { gouraud = !gouraud; } );
	shortcut.add( "ALT+n", function() { color_normals = !color_normals;	} );
	shortcut.add( "ALT+a", function() { animate = !animate; } );
	shortcut.add( "p",     ( function(self) { return function() { self.m_axis.basis_selection++; }; } ) (this) );
	shortcut.add( "m",     ( function(self) { return function() { self.m_axis.basis_selection--; }; } ) (this) );	
}

// Animation.prototype.update_strings = function( debug_screen_strings )	      // Strings that this displayable object (Animation) contributes to the UI:	
// {
// 	debug_screen_strings.string_map["time"]    = "Animation Time: " + this.graphicsState.animation_time/1000 + "s";
// 	debug_screen_strings.string_map["basis"]   = "Showing basis: " + this.m_axis.basis_selection;
// 	debug_screen_strings.string_map["animate"] = "Animation " + (animate ? "on" : "off") ;
// 	debug_screen_strings.string_map["thrust"]  = "Thrust: " + thrust;
// }

function update_camera( self, animation_delta_time )
	{
		var leeway = 70,  degrees_per_frame = .0004 * animation_delta_time,
                      meters_per_frame  =   .01 * animation_delta_time;
										
    if( self.mouse.anchor ) // Dragging mode: Is a mouse drag occurring?
    {
      var dragging_vector = subtract( self.mouse.from_center, self.mouse.anchor);           // Arcball camera: Spin the scene around the world origin on a user-determined axis.
      if( length( dragging_vector ) > 0 )
        self.graphicsState.camera_transform = mult( self.graphicsState.camera_transform,    // Post-multiply so we rotate the scene instead of the camera.
            mult( translation(origin),                                                      
            mult( rotation( .05 * length( dragging_vector ), dragging_vector[1], dragging_vector[0], 0 ), 
            translation(scale_vec( -1,origin ) ) ) ) );
    }    
          // Flyaround mode:  Determine camera rotation movement first
		var movement_plus  = [ self.mouse.from_center[0] + leeway, self.mouse.from_center[1] + leeway ];  // mouse_from_center[] is mouse position relative to canvas center;
		var movement_minus = [ self.mouse.from_center[0] - leeway, self.mouse.from_center[1] - leeway ];  // leeway is a tolerance from the center before it starts moving.
		
		for( var i = 0; looking && i < 2; i++ )			// Steer according to "mouse_from_center" vector, but don't start increasing until outside a leeway window from the center.
		{
			var velocity = ( ( movement_minus[i] > 0 && movement_minus[i] ) || ( movement_plus[i] < 0 && movement_plus[i] ) ) * degrees_per_frame;	// Use movement's quantity unless the &&'s zero it out
			self.graphicsState.camera_transform = mult( rotation( velocity, i, 1-i, 0 ), self.graphicsState.camera_transform );			// On X step, rotate around Y axis, and vice versa.
		}
		self.graphicsState.camera_transform = mult( translation( scale_vec( meters_per_frame, thrust ) ), self.graphicsState.camera_transform );		// Now translation movement of camera, applied in local camera coordinate frame
	}

// A short function for testing.  It draws a lot of things at once.  See display() for a more basic look at how to draw one thing at a time.
Animation.prototype.test_lots_of_shapes = function( model_transform )
  {
    var shapes = [ this.m_prism, this.m_capped, this.m_cone, this.m_sub, this.m_sphere, this.m_obj, this.m_torus ];   // Randomly include some shapes in a list
    var tex_names = [ undefined, "stars.png", "earth.gif" ]
    
    for( var i = 3; i < shapes.length + 3; i++ )      // Iterate through that list
    {
      var spiral_transform = model_transform, funny_number = this.graphicsState.animation_time/20 + (i*i)*Math.cos( this.graphicsState.animation_time/2000 );
      spiral_transform = mult( spiral_transform, rotation( funny_number, i%3 == 0, i%3 == 1, i%3 == 2 ) );    
      for( var j = 1; j < 4; j++ )                                                                                  // Draw each shape 4 times, in different places
      {
        var mat = new Material( Color( i % j / 5, j % i / 5, i*j/25, 1 ), .3,  1,  1, 40, tex_names[ (i*j) % tex_names.length ] )       // Use a random material
        // The draw call:
        shapes[i-3].draw( this.graphicsState, spiral_transform, mat );			                        //  Draw the current shape in the list, passing in the current matrices		
        spiral_transform = mult( spiral_transform, rotation( 63, 3, 5, 7 ) );                       //  Move a little bit before drawing the next one
        spiral_transform = mult( spiral_transform, translation( 0, 5, 0) );
      } 
      model_transform = mult( model_transform, translation( 0, -3, 0 ) );
    }
    return model_transform;     
  }
    
// *******************************************************	
// display(): Called once per frame, whenever OpenGL decides it's time to redraw.

Animation.prototype.display = function(time)
	{  
		if(!time) time = 0;                                                               // Animate shapes based upon how much measured real time has transpired
		this.animation_delta_time = time - prev_time;                                     // by using animation_time
		if( animate ) this.graphicsState.animation_time += this.animation_delta_time;
		prev_time = time;
		this.fps = 1000/this.animation_delta_time;
	  //update_camera( this, this.animation_delta_time);
    this.graphicsState.camera_transform = lookAt(vec3(camera_x,camera_y,camera_z),vec3(obj_x,obj_y,obj_z),vec3(0,1,0));
			
		var model_transform = mat4();	            // Reset this every frame.
		this.basis_id = 0;	                      // For the "axis" shape.  This variable uniquely marks each axis we draw in display() as it counts them up.
    
    shaders[ "Default" ].activate();                         // Keep the flags seen by the default shader program up-to-date
		gl.uniform1i( g_addrs.GOURAUD_loc, gouraud );		gl.uniform1i( g_addrs.COLOR_NORMALS_loc, color_normals);    
		
    
		// *** Lights: *** Values of vector or point lights over time.  Arguments to construct a Light(): position or vector (homogeneous coordinates), color, size
    // If you want more than two lights, you're going to need to increase a number in the vertex shader file (index.html).  For some reason this won't work in Firefox.
    this.graphicsState.lights = [];                    // First clear the light list each frame so we can replace & update lights.
    
    var light_orbit = [ Math.cos(this.graphicsState.animation_time/1000), Math.sin(this.graphicsState.animation_time/1000) ];
    this.graphicsState.lights.push( new Light( vec4(  30 ,  30,  34 , 1 ), Color( 0, .4, 0, 1 ), 100000 ) );
    this.graphicsState.lights.push( new Light( vec4( -10 , -20, -14 , 0 ), Color( 1, 1, .3, 1 ), 100 * Math.cos(this.graphicsState.animation_time/10000 ) ) );
    
		// *** Materials: *** Declare new ones as temps when needed; they're just cheap wrappers for some numbers.
		// 1st parameter:  Color (4 floats in RGBA format), 2nd: Ambient light, 3rd: Diffuse reflectivity, 4th: Specular reflectivity, 5th: Smoothness exponent, 6th: Texture image.
		var purplePlastic = new Material( Color( .9,.5,.9,1 ), .01, .2, .4, 40 ), // Omit the final (string) parameter if you want no texture
          greyPlastic = new Material( Color( .5,.5,.5,1 ), .01, .4, .2, 20 ),
                earth = new Material( Color( .5,.5,.5,1 ), .1,  1, .5, 40, "earth.gif" ),
                stars = new Material( Color( .5,.5,.5,1 ), .1,  1,  1, 40, "stars.png" );
			
		/**********************************
		Start coding down here!!!!
		**********************************/                                    // From this point on down it's just some examples for you -- feel free to comment it all out.
    var model_transform = mult(scale(500,500,500),rotation(90,0,1,0));
    model_transform = mult(translation(0,0,-50),model_transform);
    var test_color = new Material(Color( 1,.8,.6,1 ), .6, .2, .4, 40);

    // this.cloud.draw(this.graphicsState,model_transform,cloud_color);
    // this.stars.draw(this.graphicsState,model_transform,star_color);
    this.drawbg();
    //this.m_strip.draw(this.graphicsState,model_transform,bg_color);
    //this.door.draw(this.graphicsState,model_transform,test_color);
    //model_transform = mult(scale(2,2,2),model_transform);
      this.camera_motion();

      //this.drawrobot(model_transform);
      //this.test(this.graphicsState.animation_time);
    if (this.graphicsState.animation_time > 2000) {
      model_transform = mult(rotation(body_angle,0,1,0),scale(0.7,0.7,0.7));
      model_transform = mult(translation(x_pos,y_pos,z_pos),model_transform);
      this.drawrobot(model_transform);
      this.robot_motion(this.graphicsState.animation_time-2000);
    }

    
    if (this.graphicsState.animation_time < 6000) {
      model_transform = mult(translation(-7,70,text_z),mat4())
      this.m_text.draw(this.graphicsState,model_transform,this.iron_color);
      model_transform = mult(translation(bird_pos_x,bird_pos_y,bird_pos_z),rotation(-90,0,1,0));

      this.drawbird(model_transform);
    }
    
    model_transform = mat4();
    this.drawscene(model_transform);
    
	}	

Animation.prototype.drawbg = function(){
  var star_color = new Material(Color( 1,1,.1,0.8 ), .8, .2, .4, 40);
  var cloud_color = new Material(Color( 0.9,0.9,0.9,0.8 ), 1, .2, .4, 40);
  var model_transform;
   var k = Math.random()*20+30;
   var k2 = Math.random()*10+20;
  for (var i = -100; i <=100 ; i = i+k) {
    k = Math.random()*10+30;
    for (var j = -100; j <=100; j = j+k2) {
      k2 = Math.random()*20+20;
      model_transform = mult(translation(i,j,-30),mat4());
      if (this.graphicsState.animation_time > 44000 && this.graphicsState.animation_time < 44100) {
        this.context = new GL_Context( "gl-canvas", Color(0.06,0.19,0.4,0.8));
      }
      if (this.graphicsState.animation_time > 44000) {       
        this.stars.draw(this.graphicsState,model_transform,star_color);
      }else{
        this.cloud.draw(this.graphicsState,model_transform,cloud_color);
      }
      
    }

  }

}

//robot bird part
Animation.prototype.drawbird= function(model_transform){
this.drawbird_head(model_transform);
this.drawbird_leg(model_transform);
var stack = [];
stack.push(model_transform);
model_transform = mult(model_transform,translation(-1,0,0));
this.drawbird_wings(model_transform);
model_transform = stack.pop();
var model_temp = mult(translation(1,0,0),rotation(180,0,1,0));
model_transform = mult(model_transform,model_temp);
this.drawbird_wings(model_transform);

}

Animation.prototype.drawbird_head=function(model_transform){
  // var head = new Subdivision_Sphere(4,true);
  // var body = new Capped_Cylinder( 4, 12 );
  var eye_ball_color = new Material(Color( 0.2,.2,.2,1 ), .6, .2, .4, 40);

  var model_transform1 = mult(scale(1,1,1),mat4());
  model_transform1 = mult(model_transform,model_transform1);
  this.m_sub.draw(this.graphicsState,model_transform1,this.copper_color);

  model_transform1 = mult(scale(1,1.5,1),rotation(90,1,0,0));
  model_transform1 = mult(translation(0,-0.5,0),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_capped.draw(this.graphicsState,model_transform1,this.copper_color);

  //eye
  model_transform1 = mult(scale(0.4,0.4,0.4),mat4());
  model_transform1 = mult(translation(0.6,0,1),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_sub.draw(this.graphicsState,model_transform1,this.copper_color);

  model_transform1 = mult(scale(0.1,0.1,0.1),mat4());
  model_transform1 = mult(translation(0.6,0,1.4),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_sub.draw(this.graphicsState,model_transform1,eye_ball_color);

  model_transform1 = mult(scale(0.4,0.4,0.4),mat4());
  model_transform1 = mult(translation(-0.6,0,1),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_sub.draw(this.graphicsState,model_transform1,this.copper_color);

  model_transform1 = mult(scale(0.1,0.1,0.1),mat4());
  model_transform1 = mult(translation(-0.6,0,1.4),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_sub.draw(this.graphicsState,model_transform1,eye_ball_color);

  //mouth
  var nose = new Tetrahedron();
  model_transform1 = mult(rotation(135,0,1,0),scale(0.3,1,0.3));
  model_transform1 = mult(translation(0,-1,1.2),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  nose.draw(this.graphicsState,model_transform1,this.copper_color);



}

Animation.prototype.drawbird_leg=function(model_transform){

  var leg_color = new Material(Color( 1,.8,.6,1 ), .6, .2, .4, 40);
  var model_transform1 = mult(scale(0.2,0.2,0.2),rotation(90,1,0,0));
  model_transform1 = mult(translation(0.4,-1.4,0),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_capped.draw(this.graphicsState,model_transform1,this.copper_color);

  model_transform1 = mult(scale(0.1,0.6,0.1),rotation(90,1,0,0));
  model_transform1 = mult(translation(0.4,-1.6,0),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_capped.draw(this.graphicsState,model_transform1,this.copper_color);


  model_transform1 = mult(scale(0.2,0.2,0.2),rotation(90,1,0,0));
  model_transform1 = mult(translation(-0.4,-1.4,0),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_capped.draw(this.graphicsState,model_transform1,this.copper_color);

  model_transform1 = mult(scale(0.1,0.6,0.1),rotation(90,1,0,0));
  model_transform1 = mult(translation(-0.4,-1.6,0),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_capped.draw(this.graphicsState,model_transform1,this.copper_color);

  //add feet



}
Animation.prototype.drawbird_wings=function(model_transform){
  model_transform = mult(model_transform,translation(0.5,0,0));
  model_transform = mult(model_transform,rotation(wings_angle,0,0,1));
  model_transform = mult(model_transform,translation(-0.5,0,0));
  //var wing_color = new Material(Color( 1,.8,.6,1 ), .6, .2, .4, 40);
  var model_transform1 = mult(scale(1,0.2,1),mat4());
  model_transform1 = mult(model_transform,model_transform1);
  this.m_cube.draw(this.graphicsState,model_transform1,this.copper_color);

  model_transform1 = mult(scale(0.5,0.2,0.5),rotation(90,1,0,0));
  model_transform1 = mult(translation(-0.5,0,0),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_capped.draw(this.graphicsState,model_transform1,this.copper_color);


}

Animation.prototype.camera_motion = function(){
  if (this.graphicsState.animation_time > 0 && this.graphicsState.animation_time < 2000) {
        wings_angle = 30*Math.sin(this.graphicsState.animation_time*Math.PI/50);
        bird_pos_x = 10 - this.graphicsState.animation_time/100;
        text_z = 50 + this.graphicsState.animation_time / 500;
        camera_x = camera_x - 0.5;
        camera_z = camera_z - 2;

  }

  if (this.graphicsState.animation_time > 2000 && this.graphicsState.animation_time < 4000) {
    wings_angle = 30*Math.sin(this.graphicsState.animation_time*Math.PI/50);
    bird_pos_x = 10 - this.graphicsState.animation_time/100;
    text_z = 50 + this.graphicsState.animation_time / 500;
    if (camera_y > 30) {
        camera_y = camera_y - 10;
        obj_y = obj_y - 10;
        if (camera_x < 0) {
          camera_x = camera_x + 0.5;
        }
    }
  }

  if (this.graphicsState.animation_time > 2000 && this.graphicsState.animation_time < 3000) {
    if (camera_z > 20) {
        camera_z = camera_z - 5;
        camera_y = camera_y - 2;
    }
  }
  if (this.graphicsState.animation_time > 29000 && this.graphicsState.animation_time <= 40000) {
    if (obj_x > -6 ) {
      obj_x = obj_x - 2;
    }
    if (camera_z > -4) {
      camera_z = camera_z - 1;
      camera_y = camera_y - 0.1;
      camera_x = camera_x + 0.3;
      obj_z = obj_z - 0.6;
      obj_y = obj_y - 0.5;
    }
  }

  if (this.graphicsState.animation_time > 44000 && this.graphicsState.animation_time <= 62000) {
    if (camera_z < 50) {
      camera_z = camera_z + 1;
    }
  }

  if (this.graphicsState.animation_time > 73000 ) {
    if (camera_z > 35) {
      camera_z = camera_z - 1;
    }
  }

  if (this.graphicsState.animation_time > 60000) {
    doc = "night.png";
  }
  // if (this.graphicsState.animation_time > 2000) {

  // }


}

Animation.prototype.robot_motion = function(input_time){



  if (input_time >= 0 &&input_time  <= 2000) {
    if (door_angle < 90) {
      door_angle = input_time/20;
    }
  }
  //3s walk
  if (input_time >= 2000 &&input_time  <= 4000) {

    if (z_pos < -8.0) {
      this.walk(input_time);
      z_pos = -16 + (input_time-2000)/200;
    }else{
      this.walkadjust(input_time);
    }
  }

  if (input_time > 4000 &&input_time  <= 5000) {
    this.walkadjust(input_time);

  }



  if (input_time > 5000 &&input_time  <= 6000) {
    if (body_angle > -90) {
      body_angle = -(input_time-5000)/10;
    }
  }

  if (input_time > 6000 &&input_time  <= 9000) {

    if (x_pos > 4.0) {//x_pos = 10
      this.walk(input_time);
      //x_pos = x_pos - 0.2;
      x_pos = 22 - input_time/500;
    } else{
      this.walkadjust(input_time);
    }
    
  }

  if (input_time > 9000 &&input_time  <= 10000) {
    this.walkadjust(input_time);

  }


  //door close
  if (input_time > 7000 &&input_time <= 10000) {
    if (door_angle > 0) {
      door_angle = 440-input_time/20;
    }
  }

  if (input_time > 10000 &&input_time <= 11000) {
    if (body_angle < 0) {
      body_angle = -90+(input_time-10000)/10;
    }
  }

  if (input_time > 11000 &&input_time <= 12000) {
      if (y_pos < 5) {
      y_pos = 4+(input_time-11000)/1000;
    }
   }

  // //charge up
  if (input_time > 12000  &&input_time <= 13000) {

    if (battery > 4) {
      battery = 6 - (input_time-12000)/500;
    }

  }

  // //put down robot

  if (input_time > 13000 &&input_time <= 14000) {
  if (y_pos > 4) {
      y_pos=5-(input_time-13000)/500;
      y_pos = y_pos-0.25;
      //y_pos = y_pos-0.25;
    }
  }



  if (input_time > 14000 &&input_time < 15000) {
    if (body_angle > -90) {
      body_angle = 0-(input_time-14000)/10;
      //body_angle = body_angle - 9;
    }
  }

  if (input_time > 15000 &&input_time <= 18000) {
    if (x_pos > -5.5) {
      this.walk(input_time);
      x_pos = 4 - (input_time - 15000)/300;
      //x_pos = x_pos - 0.5;
    }else{
      this.walkadjust(input_time);
    }
  }


  if (input_time > 18000 &&input_time <= 19000) {
    this.walkadjust(input_time);
  }


  if (input_time > 19000 &&input_time <= 20000) {
    if (arm_angle2 > -20) {
      arm_angle2 = 0 - (input_time - 19000)/10;
      //arm_angle2 = arm_angle2 - 5;
    }
  }

  if (input_time > 20000 &&input_time <= 21000) {
    if (arm_angle6 > -30) {
      arm_angle6 = 0 - (input_time - 20000)/20;
      //arm_angle6 = arm_angle6 -5;
    }
  }

  //lift hand
  if (input_time > 21000 &&input_time < 22000) {

    if (chair_pos < -6.5) {

      arm_angle10 = (input_time - 21000)/20;
      chair_pos = -8.5 + (input_time - 21000)/500;
      //arm_angle10 = arm_angle10 + 10;
      //chair_pos = chair_pos + 0.25;
      
    }
  }


  if (input_time > 22000 &&input_time <= 23000) {
    if (arm_angle10 > 0) {
      arm_angle10 = 50 - (input_time - 22000)/20;
      //arm_angle10 = arm_angle10 - 5;

    }
  }


  if (input_time > 23000 &&input_time <= 24000) {
    if (arm_angle6 < 0) {
      //arm_angle6 = arm_angle6 + 10;
      arm_angle6 = -30 + (input_time-23000)/20;
    }
  }


  if (input_time > 24000 &&input_time <= 25000) {
    if (arm_angle2 < 0) {
      arm_angle2 = -20+(input_time - 24000)/20;
    }
  }
  // //put down hand

  // // walk
  if (input_time > 25000 &&input_time <= 26000) {
    if (x_pos > -7.5) {
      x_pos = -5.5 - (input_time - 25000)/500;
      //x_pos = x_pos - 0.25;
      this.walk(input_time);
    }else{
      this.walkadjust(input_time);
    }
  }

  // //turn 

  if (input_time > 26000 &&input_time <= 27000) {
    if (body_angle > -180) {
      body_angle = -90 - (input_time - 26000)/10;
      //body_angle = body_angle - 9;
    }
  }

  // //sit

  if (input_time > 27000 &&input_time <= 28000) {
    if (leg_angle3 > -50) {
      leg_angle3 = -(input_time - 27000)/20;
      //leg_angle3 = leg_angle3 - 5;
    }
    if (leg_angle4 > -50) {
      leg_angle4 = -(input_time - 27000)/20;
      //leg_angle4 = leg_angle4 - 5;
    }
  }

  if (input_time > 28000 &&input_time <= 29000) {
    if (chair_pos > -7.5) {
      z_pos = -8.0 - (input_time - 28000)/500;//z_pos = -8
      chair_pos = -6.5 - (input_time - 28000)/500;//8.5 - > 6.5
      // chair_pos = chair_pos - 0.5;
      // z_pos = z_pos - 0.5;
    }

  }

  // //lift hand 

  if (input_time > 29000 &&input_time <= 30000) {
    if (arm_angle3 > -70) {
      arm_angle3 = -10-(input_time - 29000)/10;
      //arm_angle3 = arm_angle3 - 5;
    }
    if (arm_angle4 < 70) {
      arm_angle4 = 10+(input_time - 29000)/10;
      //arm_angle4 = arm_angle4 + 5;
    }
  }

  // //lift arm
  if (input_time > 31000 &&input_time <= 32000) {
    if (arm_angle1 > -40) {
      arm_angle1 = -(input_time - 31000)/20;
      //arm_angle1 = arm_angle1 - 5;
    }
    if (arm_angle2 > -40) {
      arm_angle2 = -(input_time - 31000)/20;
      //arm_angle2 = arm_angle2 - 5;
    }

    if (arm_angle5 > -90) {
      arm_angle5 = -(input_time - 31000)/10;
      //arm_angle5 = arm_angle5 - 5;
    }
    if (arm_angle6 > -90) {
      arm_angle6 = -(input_time - 31000)/10;
      //arm_angle6 = arm_angle6 - 5;
    }
  }

  
  // //type
  if (input_time > 32000 &&input_time <= 36000) {
      this.sound1.play();
      arm_angle7 = -30*Math.sin(input_time/100.0*Math.PI);
      arm_angle8 = 30*Math.sin(input_time/100.0*Math.PI);
  }
  // //put down hands
  if (input_time > 36000 &&input_time < 37000) {
    if (arm_angle1 < 0) {
      arm_angle1 = -40+(input_time - 36000)/20;
      //arm_angle1 = arm_angle1 + 5;
    }
    if (arm_angle2 < 0) {
      arm_angle2 = -40+(input_time - 36000)/20;
      //arm_angle2 = arm_angle2 + 5;
    }

    if (arm_angle5 < 0) {
      arm_angle5 = -90+(input_time - 36000)/10;
      //arm_angle5 = arm_angle5 + 5;
    }
    if (arm_angle6 < 0) {
      arm_angle6 = -90+(input_time - 36000)/10;
      //arm_angle6 = arm_angle6 + 5;
    }
  }

  if (input_time > 37000 &&input_time <= 39000) {
    if (arm_angle3 < -10) {
      arm_angle3 = -70 + (input_time - 37000)/20;
      //arm_angle3 = arm_angle3 + 5;
    }
    if (arm_angle4 > 10) {
      arm_angle4 = 70 - (input_time - 37000)/20;
      //arm_angle4 = arm_angle4 - 5;
    }
  }

  // //stand up from chair

  if (input_time > 39000 &&input_time <= 41000) {
    if (leg_angle3 < 0) {
      leg_angle3 = -50 + (input_time - 39000)/40;
      //leg_angle3 = leg_angle3 + 10;
    }
    if (leg_angle4 < 0) {
      leg_angle4 = -50 + (input_time - 39000)/40;
      //leg_angle4 = leg_angle4 + 10;
      chair_pos = -6.5 + (input_time - 39000)/1000; 
      //chair_pos = chair_pos + 0.25;
    }

  }

  // //turn around
  if (input_time > 41000 &&input_time <= 43000) {
    if (body_angle > -270) {
      body_angle = -180 - (input_time - 41000)/20;
      //body_angle = body_angle - 9;
    }
  }

  // // left chair
  if (input_time > 43000 &&input_time <= 44000) {
    if (x_pos < -4.5) {
      x_pos = -7.5 + (input_time - 43000)/200;
      //x_pos = x_pos + 0.25;
      this.walk(input_time)
    }else{
      this.walkadjust(input_time);
    }
  }

  // //turn around prepare to walk to the sofa
  if (input_time > 44000 &&input_time <= 45000) {
    if (body_angle > -360) {
      body_angle = -270 - (input_time-44000)/10;
      //body_angle = body_angle - 9;
    }
  }

  // //walk to sofa
  if (input_time > 45000 &&input_time <= 49000) {
    body_angle = 0;
    if (z_pos < 2.5) {
      this.walk(input_time);
      z_pos = -8 + (input_time - 45000)/250; 
      //z_pos = z_pos + 0.5;
    }else{
      this.walkadjust(input_time);
    }
  }

  if (input_time > 49000 &&input_time <= 50000) {
    if (body_angle > -90) {
      body_angle = -(input_time - 49000)/10;
      //body_angle = body_angle - 10;
    }
  }

  if (input_time > 50000 &&input_time <= 53000) {
    if (x_pos > -9) {
      x_pos = -4.5 - (input_time - 50000)/500;//-4.5
      //x_pos = x_pos - 0.5;
      this.walk(input_time);
    }else{
      this.walkadjust(input_time);
    }
  }


  // //turn around

  if (input_time > 53000 &&input_time <= 56000) {
    if (body_angle < 45) {
      body_angle = -90 + (input_time - 53000)/15;
      //body_angle = body_angle + 5;
    }
  }

  // //sit down

  if (input_time > 56000 &&input_time <= 58000) {
    if (leg_angle3 > -80) {
      leg_angle3 = -(input_time - 56000)/25;
      //leg_angle3 = leg_angle3 - 5;
    }
    if (leg_angle4 > -80) {
      leg_angle4 = -(input_time - 56000)/25;
      leg_angle4 = leg_angle4 - 5;
    }
  }

  // //shake head
  if (input_time > 58000 &&input_time <= 63000) {
    this.sound2.play();
    head_angle = 20 * Math.sin(input_time/500.0*Math.PI);
  }

  // //adjust head
  if (input_time > 63000 &&input_time <= 64000) {
    if (head_angle < -1 || head_angle > 1) {
          head_angle = 20 * Math.sin(input_time/500.0*Math.PI);
    }
  }

  // //stand up

  if (input_time > 64000 &&input_time <= 66000) {
    if (leg_angle3 < 0) {
      leg_angle3 = -80 + (input_time - 64000)/25;
      //leg_angle3 = leg_angle3 + 5;
    }
    if (leg_angle4 < 0) {
      leg_angle4 = -80 + (input_time - 64000)/25;
      //leg_angle4 = leg_angle4 + 5;
    }
  }

  // //turn around

  if (input_time > 66000 &&input_time <= 68000) {
    if (body_angle < 145) {
      //body_angle = body_angle + 5;
      body_angle = 45 + (input_time-66000)/20;
    }
  }

  // //walk to the door

  if (input_time > 68000 &&input_time <= 72000) {
    if (x_pos < 9) {
      this.walk(input_time);
      x_pos = -9 + (input_time - 68000)/250;
      z_pos = 2.5 - (input_time - 68000)/400; //
      //x_pos = x_pos + 0.45;
      //z_pos = z_pos - 0.4;
    }else{
      this.walkadjust(input_time);
    }
  }


  //open the door
  if (input_time >= 72000 &&input_time <= 74000) {
    if (arm_angle1 > -40) {
      arm_angle1 = -(input_time - 72000)/40;
      //arm_angle1 = arm_angle1 - 5;
    }
    // if (arm_angle3 > -70) {
    //   arm_angle3 = -10 - (input_time - 72000)/20;
    //   //arm_angle3 = arm_angle3 -5;
    // }

    if (arm_angle5 > -100) {
      arm_angle5 = -(input_time - 72000)/20;
      //arm_angle5 = arm_angle5 - 5;
    }
  }

  if (input_time >= 74000 &&input_time <= 76000) {
    if (door_angle < 90){
      arm_angle9 = -(input_time - 74000)/20;
      door_angle = (input_time - 74000)/20;
      //arm_angle9 = arm_angle9 + 10;
      //door_angle = door_angle + 9;
    }
  }

  // //put down the hand


  // //walk in & close the door
  if (input_time > 76000 &&input_time <= 80000) {
    if (x_pos < 14) {
      x_pos = 9.5+ (input_time - 76000)/500;//x_pos 9.5
      z_pos = -11.5 - (input_time - 76000)/500;
      arm_angle9 = -90 + (input_time - 76000)/30;
      //arm_angle3 = -70 + (input_time - 76000)/50;
      arm_angle1 = -40 + (input_time - 76000)/60;
      arm_angle5 = -100 + (input_time - 76000)/30;
      //x_pos = x_pos + 0.45;
      //z_pos = z_pos - 0.37;
      this.walk(input_time);

      
    }
      if (door_angle > 0) {
        door_angle = 90 - (input_time - 76000)/30;
      }
  }


  //close the door




    
}
Animation.prototype.test = function(input_time){
  // if (input_time >= 0 &&input_time <= 2000) {
  //   leg_angle3 = -45*Math.sin(input_time/2000.0*Math.PI*2);
  //   leg_angle4 = -45*Math.sin(input_time/2000.0*Math.PI*2);
  // }
  //   if (input_time > 0 &&input_time <= 2000) {
  //   arm_angle3 = 20*Math.sin(input_time/2000.0*Math.PI*2);
  //   arm_angle4 = -20*Math.sin(input_time/2000.0*Math.PI*2 );
  // }
  if (input_time > 0 &&input_time <= 1000) {
    //arm_angle5 = -70*Math.sin(input_time/2000.0*Math.PI);
    arm_angle6 = -70*Math.sin(input_time/2000.0*Math.PI);
  }

  // if (input_time > 2000 &&input_time <= 4000) {
  //   if (arm_angle2 > -45) {
  //     arm_angle2 = arm_angle2 - 5;
  //   }
  // }

  // if (input_time > 4000 &&input_time <= 6000) {
  //   if (arm_angle6 > -30) {
  //     arm_angle6 = arm_angle6 -5;
  //   }
  // }

  //lift hand
  if (input_time > 1000 &&input_time <= 2000) {

    if (arm_angle10 < 40) {
      arm_angle10 = arm_angle10 + 20;
      //chair_pos = chair_pos + 0.25;
      
    }
  }

}

Animation.prototype.walk = function(input_time){
      leg_angle1 = 10*Math.sin(input_time/1000.0*Math.PI);
      leg_angle2 = -10*Math.sin(input_time/1000.0*Math.PI);
      arm_angle1 = -10*Math.sin(input_time/1000.0*Math.PI);
      arm_angle2 = 10*Math.sin(input_time/1000.0*Math.PI);
}

Animation.prototype.walkadjust = function(input_time){
    if (leg_angle1 > 1 || leg_angle1 < -1) {
      leg_angle1 = 10*Math.sin(input_time/1000.0*Math.PI);
    }
    if (leg_angle2 > 1 || leg_angle2 < -1) {
      leg_angle2 = -10*Math.sin(input_time/1000.0*Math.PI);
    }

    if (arm_angle1 > 1 || arm_angle1 < -1) {
      arm_angle1 = -10*Math.sin(input_time/1000.0*Math.PI);
    }

    if (arm_angle2 > 1 || arm_angle2 < -1) {
      arm_angle2 = 10*Math.sin(input_time/1000.0*Math.PI);
    }
}

//robot part
Animation.prototype.drawrobot = function(model_transform){
   var label_color = new Material(Color( 1,0,0,1 ), .6, .2, .4, 40);
   var model_transform2 = mult(model_transform,translation(0,4-2.5+2.5*Math.cos(leg_angle3/180*Math.PI),2.5*Math.sin(leg_angle3/180*Math.PI)));
  //
  var model_transform3 = translation(0,4,0);
  this.drawrobot_upper(model_transform2);
  //this.m_sub.draw(this.graphicsState,model_transform3,label_color);
  //model_transform = mult(rotation(90,0,1,0),mat4());
  var model_transform1 = mult(rotation(leg_angle1,1,0,0),translation(-0.5,-2.5,0));
  model_transform1 = mult(model_transform,model_transform1);
  this.drawrobot_leg1(model_transform1,leg_angle4);
  //right
  model_transform1 = mult(rotation(leg_angle2,1,0,0),translation(0.5,-2.5,0));
  model_transform1 = mult(model_transform,model_transform1);
  this.drawrobot_leg1(model_transform1,leg_angle3);
}


Animation.prototype.drawrobot_upper = function(model_transform){
  this.drawrobot_head(model_transform);
  var model_transform1 = mult(model_transform,translation(0,-1,0));
  this.drawrobot_body(model_transform1);

  model_transform1 = mult(translation(-1,-1.5,0),rotation(arm_angle3,0,0,1));
  model_transform1 = mult(model_transform,model_transform1);
  model_transform1 = mult(model_transform1,rotation(arm_angle1,1,0,0))
  this.drawrobot_arm_left1(model_transform1,arm_angle1,arm_angle5,arm_angle9);

  model_transform1 = mult(translation(1,-1.5,0),rotation(arm_angle4,vec3(0,0,1)));
  model_transform1 = mult(model_transform,model_transform1);
  model_transform1 = mult(model_transform1,rotation(arm_angle2,1,0,0))
  this.drawrobot_arm_right(model_transform1);



}

Animation.prototype.drawrobot_head = function(model_transform){
model_transform = mult(model_transform,translation(0,-1,0));
model_transform = mult(model_transform,rotation(head_angle,0,0,1));
model_transform = mult(model_transform,translation(0,1,0));
var model_transform1 = mult(scale(2,1,1),mat4());
//var head = new Subdivision_Sphere(4,true);
//var head_color = new Material(Color( 1,.8,.6,1 ), .6, .2, .4, 40);
var eye_ball_color = new Material(Color(0.2,0.2,0.2,1 ), .6, .2, .4, 40);
model_transform1 = mult(model_transform,model_transform1);
this.m_sub.draw(this.graphicsState,model_transform1,this.iron_color);

//eye
var model_transform2 = mult(translation(0.8,0,1),scale(0.4,0.4,0.4));
model_transform2 = mult(model_transform,model_transform2);
this.m_sub.draw(this.graphicsState,model_transform2,this.copper_color);

model_transform2 = mult(translation(0.8,0,1.4),scale(0.1,0.1,0.1));
model_transform2 = mult(model_transform,model_transform2);
this.m_sub.draw(this.graphicsState,model_transform2,eye_ball_color);

model_transform2 = mult(translation(-0.8,0,1),scale(0.4,0.4,0.4));
model_transform2 = mult(model_transform,model_transform2);
this.m_sub.draw(this.graphicsState,model_transform2,this.copper_color);

model_transform2 = mult(translation(-0.8,0,1.4),scale(0.1,0.1,0.1));
model_transform2 = mult(model_transform,model_transform2);
this.m_sub.draw(this.graphicsState,model_transform2,eye_ball_color);




//ear
model_transform2 = mult(translation(1.6,0,0),scale(0.6,0.6,0.6));
model_transform2 = mult(model_transform,model_transform2);
this.m_sub.draw(this.graphicsState,model_transform2,this.iron_color);

model_transform2 = mult(translation(2.3,0,0),scale(0.3,0.1,0.1));
model_transform2 = mult(model_transform,model_transform2);
this.m_sub.draw(this.graphicsState,model_transform2,this.iron_color);


model_transform2 = mult(translation(-1.6,0,0),scale(0.6,0.6,0.6));
model_transform2 = mult(model_transform,model_transform2);
this.m_sub.draw(this.graphicsState,model_transform2,this.iron_color);

model_transform2 = mult(translation(-2.3,0,0),scale(0.3,0.1,0.1));
model_transform2 = mult(model_transform,model_transform2);
this.m_sub.draw(this.graphicsState,model_transform2,this.iron_color);


//hair?
model_transform2 = mult(translation(0,1,0),scale(0.1,0.1,0.1));
model_transform2 = mult(model_transform,model_transform2);
this.m_sub.draw(this.graphicsState,model_transform2,this.iron_color);




}

Animation.prototype.drawrobot_body = function(model_transform){
//neck
//var neck = new Capped_Cylinder(4,12);
var model_transform1 = mult(scale(0.7,0.7,0.7,1),rotation(90,1,0,0));
model_transform1 = mult(model_transform,model_transform1);
//var neck_color = new Material(Color( 1,.8,.6,1 ), .6, .2, .4, 40);
this.m_capped.draw(this.graphicsState,model_transform1,this.iron_color);

model_transform1 = mult(scale(1.2,0.2,1,1.2),rotation(90,1,0,0));
model_transform1 = mult(translation(0,-0.35,0),model_transform1);
model_transform1 = mult(model_transform,model_transform1);
this.m_capped.draw(this.graphicsState,model_transform1,this.iron_color);

//var ball = new Subdivision_Sphere(4,true);

for (var i = 0; i < 6; i++) {
  var theta = i/6.0*3.14*2;
  model_transform1 = mult(translation(1.2*Math.cos(theta),-0.35,1.2*Math.sin(theta)),scale(0.1,0.1,0.1));
  model_transform1 = mult(model_transform,model_transform1);
  this.m_sub.draw(this.graphicsState,model_transform1,this.iron_color);
  
}



model_transform1 = mult(scale(1,1,1,1),rotation(90,1,0,0));
model_transform1 = mult(translation(0,-0.7,0),model_transform1);
var model_transform_temp = model_transform1;
model_transform1 = mult(model_transform,model_transform1);
this.m_capped.draw(this.graphicsState,model_transform1,this.iron_color);

model_transform1 = model_transform_temp;
model_transform1 = mult(translation(0,-1,0),model_transform1);
model_transform_temp = model_transform1;
model_transform1 = mult(model_transform,model_transform1);
this.m_capped.draw(this.graphicsState,model_transform1,this.iron_color);

model_transform1 = model_transform_temp;
model_transform1 = mult(translation(0,-1,0),model_transform1);
model_transform1 = mult(model_transform,model_transform1);
this.m_capped.draw(this.graphicsState,model_transform1,this.iron_color);


}


Animation.prototype.drawrobot_arm_left1 = function(model_transform,arm_angle_input,arm_angle_input2,arm_angle_input3){
  //var hand_color = new Material(Color( 1,.8,.6,1 ), .6, .2, .4, 40);
  var arm_color = new Material(Color( 1,.8,.6,1 ), .6, .2, .4, 40);
  var model_transform1 = mult(scale(0.2,0.8,0.2),rotation(90,1,0,0));
  var model_transform2 = mult(scale(0.2,2.2,0.2),rotation(90,1,0,0));
  //upper
  model_transform1 = mult(translation(0,-0.4,0),model_transform1);
  //model_transform1 = mult(rotation(arm_angle_input,1,0,0),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_capped.draw(this.graphicsState,model_transform1,this.iron_color);
  //joint
  model_transform1 = mult(translation(0,-0.8,0),scale(0.2,0.2,0.2));
  model_transform1 = mult(model_transform,model_transform1);
  this.m_sub.draw(this.graphicsState,model_transform1,this.iron_color);
  //lower
  model_transform2 = mult(translation(0,-1.1,0),model_transform2);
  model_transform2 = mult(rotation(arm_angle_input2,1,0,0),model_transform2);
  model_transform2 = mult(rotation(arm_angle_input3,0,1,0),model_transform2);
  model_transform2 = mult(translation(0,-0.8,0),model_transform2);
  model_transform2 = mult(model_transform,model_transform2);
  this.m_capped.draw(this.graphicsState,model_transform2,this.iron_color);

  model_transform1 = mult(translation(0,-0.3,0),scale(0.3,0.3,0.3));
  model_transform1 = mult(rotation(arm_angle7,1,0,0),model_transform1);
  model_transform1 = mult(translation(0,-1.9,0),model_transform1);
  model_transform1 = mult(rotation(arm_angle_input2,1,0,0),model_transform1);
  model_transform1 = mult(rotation(arm_angle_input3,0,1,0),model_transform1);
  model_transform1 = mult(translation(0,-0.8,0),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_sub.draw(this.graphicsState,model_transform1,this.iron_color);

}





Animation.prototype.drawrobot_arm_right = function(model_transform){
this.drawrobot_arm_left1(model_transform,arm_angle2,arm_angle6,arm_angle10);

}
Animation.prototype.drawrobot_leg1 = function(model_transform,leg_angle_input){
  //var leg_color = new Material(Color( 1,.8,.6,1 ), .6, .2, .4, 40);
  var feet_color = new Material(Color( 1,.8,.6,1 ), .6, .2, .4, 40);
  var label_color = new Material(Color( 1,0,0,1 ), .6, .2, .4, 40);
  //this.m_sub.draw(this.graphicsState,model_transform,label_color);
  var model_transform1 = mult(scale(0.15,1.5,0.15),rotation(90,1,0,0));
  model_transform1 = mult(translation(0,0.75,0),model_transform1);
  model_transform1 = mult(rotation(leg_angle_input,1,0,0),model_transform1);
  model_transform1 = mult(translation(0,0.8,0),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_capped.draw(this.graphicsState,model_transform1,this.iron_color);
  //upper

  //cap
  model_transform1 = mult(translation(0,0.8,0),scale(0.3,0.3,0.3));
  model_transform1 = mult(model_transform,model_transform1);
  this.m_sub.draw(this.graphicsState,model_transform1,this.iron_color);

  //lower
  model_transform1 = mult(scale(0.15,3.5,0.15),rotation(90,1,0,0));
  model_transform1 = mult(translation(0,-0.75,0),model_transform1)
  model_transform1 = mult(rotation(0,1,0,0),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_capped.draw(this.graphicsState,model_transform1,this.iron_color);

  //feet
  model_transform1 = mult(scale(0.4,0.5,0.4),rotation(90,1,0,0));
  model_transform1 = mult(translation(0,-2.75,0),model_transform1);
  model_transform1 = mult(rotation(0,1,0,0),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_capped.draw(this.graphicsState,model_transform1,this.iron_color);
  
}



// scene

Animation.prototype.drawscene = function(model_transform){
  this.drawhouse(model_transform);

  var table_color = new Material(Color( 1,.8,.6,1 ), .6, .2, .4, 40);
  var chair_color = new Material(Color( 1,.8,.7,1 ), .3, .2, .4, 40);
  var desk_color = new Material(Color( 1,.8,.7,1 ), .6, .2, .4, 40);
  var lamp_color = new Material(Color( 1,.8,.7,1 ), .6, .2, .4, 40);
  var sofa_color = new Material(Color( 1,.8,.7,1 ), .6, .2, .4, 40);
  var birdperch_color = new Material(Color( 1,.8,.7,1 ), .6, .2, .4, 40);
  var model_transform1 = mult(model_transform,translation(0,0.5,4));
  var pc_color = new Material(Color( 0.8,.8,.8,1 ), .3, .2, .4, 40);
  var tv_color = new Material(Color( 0.8,.8,.8,1 ), .3, .2, .4, 40);
  var cabinet_color = new Material(Color( 1,.8,.7,1 ), .2, .2, .4, 40);
  var charger_color = new Material(Color( 1,1,1,0.3 ), .3, .2, .4, 40);
  var liquid_color = new Material(Color( 0,0,1,0.7 ), 0.6, .2, .4, 40);

  this.table.draw(this.graphicsState,model_transform1,table_color);
  model_transform1 = mult(translation(-7.8,1.5,chair_pos),rotation(180,0,1,0));
  model_transform1 = mult(model_transform,model_transform1);
  this.chair.draw(this.graphicsState,model_transform1,chair_color);
  model_transform1 = mult(translation(-13,0.5,-13),rotation(-90,0,1,0));
  model_transform1 = mult(model_transform,model_transform1);
  this.desk.draw(this.graphicsState,model_transform1,desk_color);
  model_transform1 = mult(translation(-11,0.5,0),rotation(45,0,1,0));
  model_transform1 = mult(model_transform,model_transform1);
  this.sofa.draw(this.graphicsState,model_transform1,sofa_color);

  model_transform1 = mult(translation(-11,0.5,7),rotation(135,0,1,0));
  model_transform1 = mult(model_transform,model_transform1);
  this.sofa.draw(this.graphicsState,model_transform1,sofa_color);

  model_transform1 = mult(translation(11,5,8),mat4());
  model_transform1 = mult(model_transform,model_transform1);
  this.birdperch.draw(this.graphicsState,model_transform1,birdperch_color);

  model_transform1 = mult(translation(-4.5,0.5,12),mat4());
  model_transform1 = mult(model_transform,model_transform1);
  this.lamp.draw(this.graphicsState,model_transform1,lamp_color)

  model_transform1 = mult(translation(11,2.2,12),rotation(180,0,1,0));
  model_transform1 = mult(model_transform,model_transform1);
  this.tv.draw(this.graphicsState,model_transform1,tv_color);

  model_transform1 = mult(translation(-7.5,4.8,-10.0),mat4());
  model_transform1 = mult(model_transform,model_transform1);
  this.pc.draw(this.graphicsState,model_transform1,pc_color);

  model_transform1 = mult(translation(11,0.5,12),rotation(-45,0,1,0));
  model_transform1 = mult(model_transform,model_transform1);
  this.cabinet.draw(this.graphicsState,model_transform1,cabinet_color);

  model_transform1 = mult(scale(0.7,battery,0.7),rotation(90,1,0,0));
  model_transform1 = mult(translation(1,battery/2,-12),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_capped.draw(this.graphicsState,model_transform1,liquid_color);
  var model_transform2 = mult(scale(1,8,1),rotation(90,1,0,0));
  model_transform2 = mult(translation(1,4,-12),model_transform2);
  model_transform2 = mult(model_transform,model_transform2);
  this.m_capped.draw(this.graphicsState,model_transform2,charger_color);

  model_transform1 = mult(scale(1.2,1,1.2),rotation(90,1,0,0));
  model_transform1 = mult(translation(4,0.25,-8),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_capped.draw(this.graphicsState,model_transform1,pc_color);


}





Animation.prototype.drawhouse = function(model_transform){
//烟囱

this.drawmainhouse(model_transform);
this.drawroof(model_transform);
var bottom = new Cube();
var bottom_color = new Material(Color( 1,.8,.6,1 ), .6, .2, .4, 40);
var model_transform1 = mult(translation(0,-6,0),scale(1.5,12,1.5));
bottom.draw(this.graphicsState,model_transform1,bottom_color);

model_transform = mult(model_transform,translation(0,-10,0));
this.drawspin(model_transform);


}
Animation.prototype.drawroof = function(model_transform){
var roof = new Pyramid();
//var roof_color = new Material(Color( 1,.8,.6,1 ), .6, .2, .4, 40);
var model_transform1 = mult(translation(0,30.5,0),scale(15.5,10,15));
model_transform1 = mult(model_transform,model_transform1);
roof.draw(this.graphicsState,model_transform1,this.brick_color)

}

Animation.prototype.drawmainhouse = function(model_transform){
  //var floor = new Cube();
  //var floor_color =  new Material(Color( 1,.8,.6,1 ), .6, .2, .4, 40);
  var bedroom_color = new Material(Color( 0.9,0.9,.9,0.4 ), .8, .2, .4, 40);
  var wall_color = new Material(Color( 1,.8,.6,1 ), .4, .2, .4, 40);
  var door_color = new Material(Color( 1,.8,.6,1 ), .1, .2, .4, 40);
  var model_transform1 = mult(scale(31,1,30),mat4());
  model_transform1  = mult(model_transform,model_transform1);
  this.m_cube.draw(this.graphicsState,model_transform1,this.floor_color);//floor

  model_transform1 = mult(rotation(90,0,0,1),scale(30,1,30));
  model_transform1 = mult(translation(15,15,0),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_cube.draw(this.graphicsState,model_transform1,this.wall_color);//right wall

  model_transform1 = mult(rotation(90,0,0,1),scale(30,1,30));
  model_transform1 = mult(translation(-15,15,0),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_cube.draw(this.graphicsState,model_transform1,this.wall_color);//left_wall

  model_transform1 = mult(translation(0,30,0),scale(31,1,30));
  model_transform1  = mult(model_transform,model_transform1);
  this.m_cube.draw(this.graphicsState,model_transform1,this.floor_color);//upper

  model_transform1 = mult(rotation(90,1,0,0),scale(24,1,30));
  model_transform1 = mult(translation(-3.2,15,-15),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_cube.draw(this.graphicsState,model_transform1,this.wall_color);

  model_transform1 = mult(rotation(90,1,0,0),scale(30,1,19));
  model_transform1 = mult(translation(0,21,-15),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_cube.draw(this.graphicsState,model_transform1,this.wall_color);

  model_transform1 = mult(scale(30,1,15),mat4());
  model_transform1 = mult(translation(0,20,-7.5),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.m_cube.draw(this.graphicsState,model_transform1,this.floor_color);

  model_transform1 = mult(translation(10,7.5,-22.5),scale(15,15,15));
  model_transform1 = mult(model_transform,model_transform1);
  this.m_cube.draw(this.graphicsState,model_transform1,bedroom_color);

  //elevator

  this.drawladder(model_transform);
  //door 
  model_transform1 = mult(rotation(door_angle,0,1,0),translation(-2.6,0,0));
  model_transform1 = mult(translation(13.8,0.5,-14),model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  this.door.draw(this.graphicsState,model_transform1,door_color);


}


Animation.prototype.drawladder = function(model_transform){
  var ladder_color = new Material(Color( 1,.8,.6,1 ), .6, .2, .4, 40);
  var model_transform1 = mult(translation(10,10,0),scale(0.5,20,0.5));
  model_transform1 = mult(model_transform,model_transform1);
  this.m_cube.draw(this.graphicsState,model_transform1,ladder_color);

  model_transform1 = mult(translation(14,10,0),scale(0.5,20,0.5));
  model_transform1 = mult(model_transform,model_transform1);
  this.m_cube.draw(this.graphicsState,model_transform1,ladder_color);

  model_transform1 = mult(translation(12,10,0),scale(4,0.5,0.5));
  model_transform1 = mult(model_transform,model_transform1);
  this.m_cube.draw(this.graphicsState,model_transform1,ladder_color);

  model_transform1 = mult(translation(12,14,0),scale(4,0.5,0.5));
  model_transform1 = mult(model_transform,model_transform1);
  this.m_cube.draw(this.graphicsState,model_transform1,ladder_color);


  model_transform1 = mult(translation(12,6,0),scale(4,0.5,0.5));
  model_transform1 = mult(model_transform,model_transform1);
  this.m_cube.draw(this.graphicsState,model_transform1,ladder_color);

  model_transform1 = mult(translation(12,18,0),scale(4,0.5,0.5));
  model_transform1 = mult(model_transform,model_transform1);
  this.m_cube.draw(this.graphicsState,model_transform1,ladder_color);


  model_transform1 = mult(translation(12,2,0),scale(4,0.5,0.5));
  model_transform1 = mult(model_transform,model_transform1);
  this.m_cube.draw(this.graphicsState,model_transform1,ladder_color);

}



Animation.prototype.drawspin = function(model_transform){
var screwpart = new Torus(25,25);
var spinpart = new Cube();
var model_transform1 = mult(scale(0.5,0.5,0.5),rotation(90,1,0,0));
var screw_color = new Material(Color( 1,.8,.6,1 ), .6, .2, .4, 40);

var stack = [];

for (var i = 0; i < 3; i++) {
  model_transform1 = mult(translation(0,-0.5,0),model_transform1);
  stack.push(model_transform1);
  model_transform1 = mult(model_transform,model_transform1);
  screwpart.draw(this.graphicsState,model_transform1,screw_color);
  model_transform1 = stack.pop();
}

model_transform1 = mult(scale(8,0.5,0.5),translation(0,-2,0));
model_transform1 = mult(rotation(this.graphicsState.animation_time/100,0,1,0),model_transform1);
model_transform1 = mult(model_transform,model_transform1);
spinpart.draw(this.graphicsState,model_transform1,screw_color);

model_transform1 = mult(scale(8,0.5,0.5),translation(0,-2,0));
model_transform1 = mult(rotation(90+this.graphicsState.animation_time/100,0,1,0),model_transform1);
model_transform1 = mult(model_transform,model_transform1);
spinpart.draw(this.graphicsState,model_transform1,screw_color);


}

Animation.prototype.update_strings = function( debug_screen_strings )   // Strings this particular class contributes to the UI
{
    debug_screen_strings.string_map["fps"] ="Frame rate: "+ Math.floor(this.fps) + " fps";
    debug_screen_strings.string_map["time"] = "Animation Time: " + this.graphicsState.animation_time/1000 + "s";
}













