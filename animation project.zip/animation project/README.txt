This is the hw animation. 
Please open the index.html with firefox.